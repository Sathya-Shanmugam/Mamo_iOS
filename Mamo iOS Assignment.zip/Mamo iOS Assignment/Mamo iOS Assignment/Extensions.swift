//
//  Extensions.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 01/06/21.
//

import UIKit

class Extensions: UIView {

    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
@IBDesignable extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        get { return layer.cornerRadius }
        set {
              layer.cornerRadius = newValue

            layer.masksToBounds = (newValue > 0)
        }
    }
}
