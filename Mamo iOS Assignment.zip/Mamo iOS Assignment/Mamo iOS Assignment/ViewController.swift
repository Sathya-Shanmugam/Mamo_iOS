//
//  ViewController.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 31/05/21.
//

import UIKit
import Contacts

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource {
    
    
    var contacts = [CNContact]()
    var sectionArr = [String]()
    
    
    var frequentValues = NSArray()
    @IBOutlet weak var fetchContacts: UIBarButtonItem!
    
    var mamoAccDict = NSArray()
    @IBOutlet weak var contactsTable: UITableView!
    
    
    @IBOutlet weak var nextbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        contactsTable.isHidden = true
        nextbutton.isHidden = true
        
        //
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.contactsTable.reloadData()

        NotificationCenter.default.addObserver(self, selector: #selector(updateTable), name: NSNotification.Name(rawValue: "notifyMamo"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateTable), name: NSNotification.Name(rawValue: "notifyFrequent"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(updateBtn), name: NSNotification.Name(rawValue: "updateBtn"), object: nil)
    }
    
    @objc func updateTable(notification: NSNotification) {
        DispatchQueue.main.async {
            self.contactsTable.isHidden = false
            self.nextbutton.isHidden = false
            self.frequentValues = UserDefaults.standard.value(forKey: "frequentValue") as! NSArray
            self.mamoAccDict = UserDefaults.standard.value(forKey: "mamoValues") as! NSArray
            self.accessingContacts()
            self.contactsTable.reloadData()
        }
    }

    @objc func updateBtn(notification: NSNotification) {
        nextbutton.isEnabled = true
        nextbutton.backgroundColor = .blue
    }
    
    @IBAction func requestContactAccess(_ sender: Any) {
        switch CNContactStore.authorizationStatus(for: CNEntityType.contacts){
        case .authorized:
            DispatchQueue.main.async {
                self.accessingContacts()
            }
            break //access contacts
        case .denied, .notDetermined:  //request permission
            let alert = UIAlertController.init(title: "", message: "This application has not been granted permission to access Contacts. Please enable", preferredStyle: .alert)
            alert.addAction(UIAlertAction.init(title: "Ok", style: .default, handler: { _ in
                let urlStr = UIApplication.openSettingsURLString
                if let url = URL(string:urlStr) {
                    UIApplication.shared.open(url, options: [:], completionHandler: nil)
                }
            }))
            alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: { (alert) in
                self.dismiss(animated: true, completion: nil)
            }))
            self.present(alert, animated: true, completion: nil)
            break
        default: break
        }
    }
    
    //MARK: - Fetching Contacts
    func accessingContacts() {
        let contactFullNameKeys = [CNContactGivenNameKey as CNKeyDescriptor,
                                   CNContactFamilyNameKey as CNKeyDescriptor,
                                   CNContactEmailAddressesKey as CNKeyDescriptor,
                                   CNContactPhoneNumbersKey as CNKeyDescriptor,
                                   CNContactImageDataAvailableKey as
                                   CNKeyDescriptor,
                                   CNContactImageDataKey as CNKeyDescriptor]
            //[CNContactFormatter.descriptorForRequiredKeys(for: .fullName,.ema)]
        let contactRequest = CNContactFetchRequest(keysToFetch: contactFullNameKeys)
        let contactStore = CNContactStore()
        
        do {
            try contactStore.enumerateContacts(with: contactRequest, usingBlock: { (contact, mute) in
                self.contacts.append(contact)
                print(self.contacts[0].phoneNumbers)
                self.navigationItem.rightBarButtonItem?.title = ""
            })
        } catch {
            print("Contact unable to fetch")
        }
    }
    
    //MARK: - UITableView Delegates & DataSources
    func numberOfSections(in tableView: UITableView) -> Int {
        var sectionCount = 0
        if (UserDefaults.standard.value(forKey: "frequentValue") as! NSArray).count > 0 {
            sectionArr.append("    Frequents")
            sectionCount += 1
        }
        if mamoAccDict.count > 0 {
            sectionArr.append("    Your Friends on Mamo")
            sectionCount += 1
        }
        if contacts.count > 0 {
            sectionArr.append("    Your Contacts")
            sectionCount += 1
        }
        return sectionCount
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if sectionArr[section] == "    Frequents" {
            return 1
        } else if sectionArr[section] == "    Your Friends on Mamo" {
            return mamoAccDict.count > 0 ? mamoAccDict.count : 0
        } else {
            return contacts.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if sectionArr[indexPath.section] == "    Frequents" {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FrequentsCell", for: indexPath) as! FrequentsTableviewCell
            cell.frequentCollectionView.reloadData()
            
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "mamoAccCell", for: indexPath) as! mamoContactTableViewCell
        cell.selectionStyle = .blue
        let backgroundView = UIView()
        backgroundView.layer.borderColor = UIColor.blue.cgColor
        backgroundView.layer.borderWidth = 2.0
        cell.selectedBackgroundView = backgroundView

        if sectionArr[indexPath.section] == "    Your Friends on Mamo" {
            if mamoAccDict.count > 0 {
                if (mamoAccDict[indexPath.row] as! [String:AnyObject]).keys.contains("publicName") {
                    cell.mamoAccLabel.text = (mamoAccDict[indexPath.row] as AnyObject).value(forKey: "publicName") as? String
                } else {
                    cell.mamoAccLabel.text = (mamoAccDict[indexPath.row] as AnyObject).value(forKey: "key") as? String
                }
            }
        } else {
            print(contacts)
            cell.mamoAccLabel.text = contacts[indexPath.row].givenName
            if contacts[indexPath.row].imageDataAvailable == true, let imageData = contacts[indexPath.row].imageData {
                 cell.mamoImg.image = UIImage(data: imageData)
               }
        }

        return cell
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 35
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionArr[section]
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 110
        case 1:
            return 45
        default:
            return 40 
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view:UIView, forSection: Int) {
        if let headerView = view as? UITableViewHeaderFooterView {
            headerView.backgroundColor = .white
            headerView.textLabel?.textColor = .lightGray
            headerView.textLabel?.font = UIFont.systemFont(ofSize: 9)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var tempStr = ""
        if sectionArr[indexPath.section] == "    Your Friends on Mamo" {
            var temp1 = ""
            if (mamoAccDict[indexPath.row] as! [String:AnyObject]).keys.contains("publicName") {
                temp1 = ((mamoAccDict[indexPath.row] as AnyObject).value(forKey: "publicName") as? String)!
            }
            passName = temp1
            var temp2 = ""
            if (mamoAccDict[indexPath.row] as! [String:AnyObject]).keys.contains("id") {
                temp2 = ((mamoAccDict[indexPath.row] as AnyObject).value(forKey: "id") as? String)!
            }
            var temp3 = ""
            if (mamoAccDict[indexPath.row] as! [String:AnyObject]).keys.contains("value") {
                temp3 = ((mamoAccDict[indexPath.row] as AnyObject).value(forKey: "value") as? String)!
            }
            
            tempStr = "Contact: \(temp1) \nId : \(temp2) \nPhone number or Email : \(temp3) \nFrequent : true \nMamo : true"
        } else {
            let temp1 = contacts[indexPath.row].givenName + " " + contacts[indexPath.row].familyName
            passName = temp1

            let temp2 = (contacts[indexPath.row].emailAddresses.count) > 0 ? contacts[indexPath.row].emailAddresses.first!.value : ""
            let temp3 = (contacts[indexPath.row].phoneNumbers.count) > 0 ? contacts[indexPath.row].phoneNumbers.first!.value.stringValue : ""
            tempStr = "Contact: \(temp1) \nEmail : \(temp2) \nPhone Number:\(temp3) \nFrequent : true \nMamo : true"
        }
        passValue = tempStr
        selectedBool = true
        nextbutton.isEnabled = true
        nextbutton.backgroundColor = .blue

    }
    
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        selectedBool = false
        nextbutton.isEnabled = false
        nextbutton.backgroundColor = .systemGray6
    }
    
    @IBAction func nextAction(_ sender: Any) {
    }

}


class mamoContactTableViewCell: UITableViewCell {
    @IBOutlet weak var mamoAccLabel: UILabel!
    @IBOutlet weak var mamoImg: UIImageView!
    
}

