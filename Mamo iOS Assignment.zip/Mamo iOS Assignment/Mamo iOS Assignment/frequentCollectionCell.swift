//
//  frequentCollectionCell.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 10/06/21.
//

import UIKit

class frequentCollectionCell: UICollectionViewCell {
    @IBOutlet weak var userImage: UIImageView!
    
    @IBOutlet weak var publicName: UILabel!
}
