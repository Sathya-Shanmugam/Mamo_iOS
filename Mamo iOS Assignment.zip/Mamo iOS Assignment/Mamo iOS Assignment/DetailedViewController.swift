//
//  DetailedViewController.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 12/06/21.
//

import UIKit

class DetailedViewController: UIViewController {
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var detailLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Selected Contact Information"
        detailLabel.text = passValue
        nameLabel.text = passName
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
