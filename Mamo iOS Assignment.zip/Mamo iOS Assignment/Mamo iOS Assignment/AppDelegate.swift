//
//  AppDelegate.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 31/05/21.
//

import UIKit

var selectedBool = false
var passValue = ""
var passName = ""
@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        UserDefaults.standard.setValue([], forKey: "frequentValue")
        UserDefaults.standard.setValue([], forKey: "mamoValues")
        DispatchQueue.main.async {
            self.frequentApiCall()
            self.mamoAccApiCall()
        }
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


    func frequentApiCall() {
        let session = URLSession.shared
        let url = URL(string: "https://60adf30580a61f001733208d.mockapi.io/api/v2/frequents")!
        let task = session.dataTask(with: url, completionHandler: { data, response, error in
            // Check the response
            print(response!)
            
            // Check if an error occured
            if error != nil {
                // HERE you can manage the error
                print(error!)
                return
            }
            
            do {
                // make sure this JSON is in the format we expect
                if let json = try JSONSerialization.jsonObject(with: data!, options: []) as? [String: Any] {
                    print("json response ---->>> \(json)")
                    UserDefaults.standard.setValue(json["frequents"] as! NSArray, forKey: "frequentValue")
                    
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notifyFrequent"),object: nil)
                }
            } catch let error as NSError {
                print("Failed to load: \(error.localizedDescription)")
            }
            
        })
        task.resume()
    }
    
    func mamoAccApiCall() {
        let Url = String(format: "https://60adf30580a61f001733208d.mockapi.io/api/v2/accounts")
        guard let serviceUrl = URL(string: Url) else { return }
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "POST"
        request.setValue("Application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = nil
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            
            if let data = data {
                do {
                    
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any]
                    UserDefaults.standard.setValue(json!["mamoAccounts"]! as! NSArray, forKey: "mamoValues")
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notifyMamo"),object: nil)

                } catch {
                    print(error)
                }
            }
        }.resume()
    }
}

