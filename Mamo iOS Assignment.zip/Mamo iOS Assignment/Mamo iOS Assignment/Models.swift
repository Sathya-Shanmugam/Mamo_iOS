//
//  Models.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 10/06/21.
//

import Foundation

struct frequentList : Codable {
    var publicName : String
    var value : String
}
