//
//  FrequentsTableviewCell.swift
//  Mamo iOS Assignment
//
//  Created by sathya_shanmugam on 08/06/21.
//

import UIKit

class FrequentsTableviewCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var frequentCollectionView: UICollectionView!
    
    var loadvalue: NSArray = UserDefaults.standard.value(forKey: "frequentValue") as! NSArray
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return (UserDefaults.standard.value(forKey: "frequentValue") as! NSArray).count
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FrequentCollectionCell", for: indexPath) as! frequentCollectionCell
        cell.publicName.text = (((UserDefaults.standard.value(forKey: "frequentValue") as! NSArray)[indexPath.row] as AnyObject).value(forKey: "publicName") as! String)
        cell.userImage.image = #imageLiteral(resourceName: "profile.png")

        let backgroundView = UIView()
        backgroundView.layer.borderColor = UIColor.blue.cgColor
        backgroundView.layer.borderWidth = 2.0
        cell.selectedBackgroundView = backgroundView
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 70, height: 100)
        }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "updateBtn"),object: nil)
        selectedBool = true
        
        let temp1 = (((UserDefaults.standard.value(forKey: "frequentValue") as! NSArray)[indexPath.row] as AnyObject).value(forKey: "publicName") as! String)
        passName = temp1
        let temp2 = (((UserDefaults.standard.value(forKey: "frequentValue") as! NSArray)[indexPath.row] as AnyObject).value(forKey: "id") as! String)
        let tempStr = "Contact: \(temp1) \nId : \(temp2) \nFrequent : true \nMamo : true"
        passValue = tempStr
        
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
